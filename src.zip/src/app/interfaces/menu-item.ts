export interface MenuItem {
    ruta:string,
    texto:string
}
