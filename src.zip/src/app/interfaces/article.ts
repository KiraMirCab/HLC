export interface Article {
    nombre:string,
    precio:number,
    descuento:boolean,
    descripcion:string,
    img?:string
}
